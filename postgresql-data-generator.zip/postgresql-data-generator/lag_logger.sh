#!/bin/bash

cd "$(realpath "$(dirname "${BASH_SOURCE[0]}")")"
log_file="archive_lag.log"

[ -e "$log_file" ] && rm "$log_file"
while true
do
	date -u +"%F %T %Z |- Ready WAL File Archive Lag: $(sudo find /var/lib/instaclustr/var/lib/postgresql/data/pg_wal/archive_status/ -name *.ready | wc -l)" >> "$log_file"
	sleep 120
done
