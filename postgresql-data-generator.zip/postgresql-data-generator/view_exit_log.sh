#!/bin/bash

thread_number=$1
log_file="data_workers.log"

cd "$(realpath "$(dirname "${BASH_SOURCE[0]}")")"
grep "Exited." "$log_file"
