#!/bin/bash

pgbackrest_config='/var/lib/instaclustr/etc/pgbackrest/pgbackrest.conf'
patroni_config='/var/lib/instaclustr/etc/patroni/patroni.yml'

sudo sed -i -e '/archive-async=y/d' -e '/spool-path=.*/d' -e 's/process-max=.*/process-max=3/' "$pgbackrest_config"
sudo sed -i "s/archive_mode: 'off'/archive_mode: 'on'/" "$patroni_config"
sudo systemctl restart postgresql
