#!/bin/bash

thread=$1
desired_utilisation=$2
octets_per_loop=$3
loops=$4

volume=/var/lib/instaclustr
wal_dir="$volume/var/lib/postgresql/data/pg_wal"
max_wal_size=4194304 # 4 GiB in kB; applies to all nodes with >5 GiB of storage.
log_file="data_workers.log"


i=1
while [[ $i -le $loops ]]
do
	while [[ "$(df --output=pcent $volume | tail -n 1 | sed -e 's/[[:space:]]//g' | tr -d '%')" -ge $desired_utilisation ]]
	do
		if [[ $(sudo du -s "$wal_dir" | cut -f 1) -gt 4112488 ]]
		then
			sleep 60
		else
			date -u +"%F %T %Z |- Thread $thread: Exited. Disk at or above desired utilisation after loop $(($i-1))." >> "$log_file"
			exit
		fi
	done

	time psql -c "COPY hashTable$thread FROM PROGRAM 'bash -c \"xxd -p -c 16 -l $octets_per_loop /dev/urandom | sed \\\"s/$/,$thread/\\\"\"' WITH (FORMAT csv)"

	date -u +"%F %T %Z |- Thread $thread: Completed loop $i of $loops." >> "$log_file"
	i=$(($i+1))
done
date -u +"%F %T %Z |- Thread $thread: Exited. All loops completed." >> "$log_file"
