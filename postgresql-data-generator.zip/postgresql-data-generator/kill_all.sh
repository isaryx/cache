#!/bin/bash

sudo killall screen psql
sudo kill -9 $(ps aux | grep postgres | grep COPY | sed -e 's/5432       //' -e 's/ .*//')
