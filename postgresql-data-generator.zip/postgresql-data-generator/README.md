# Introduction

This project includes scripts to aid in loading large amounts of randomly generated data into PostgreSQL quickly. It was created to aid in the testing of backups on large DBs.
# How to run
1. Install this project onto the master of node of a PostgreSQL cluster, and `cd` into the directory.
2. Run `./setup_pgbackrest.sh [async | off]` to either disable PgBackRest, or enable asynchronous archiving and increase its `process-max` limit so it can keep up with the data being added to the db.
3. Run `./launcher.sh [storage available on node] [threads | CALCULATE]` to launch the data generation/loading process. The script will create a partitioned table using 90% of the available storage, and will use the specified number of threads/partitions to do so (or half of the available CPU cores if you use `CALCULATE`, which seems to be the right number to allow PgBackRest to keep up with WAL archiving in async mode).

If you need to terminate the process, run `./kill_all.sh`.

When you have finished loading your data, run `./restore_pgbackrest.sh` to return all settings to their default values.
