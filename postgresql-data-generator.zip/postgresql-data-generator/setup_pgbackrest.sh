#!/bin/bash

mode=$1
pgbackrest_config='/var/lib/instaclustr/etc/pgbackrest/pgbackrest.conf'
patroni_config='/var/lib/instaclustr/etc/patroni/patroni.yml'
threads=$((($(cat /proc/cpuinfo | grep $'processor' | tail -n 1 | sed 's/.*: //')+1)*3)) # Cores * 3.
spool_path='/var/lib/instaclustr/etc/pgbackrest/spool'

case "$mode" in
	async)
		! [ -d "$spool_path" ] && sudo mkdir "$spool_path" && sudo chown 5432:5432 "$spool_path" && sudo chmod 770 "$spool_path"
		[[ "$(<$pgbackrest_config)" != *"archive-async=y"* ]] &&
		sudo sed -i -e 's#compress-type=gz#compress-type=gz\narchive-async=y\nspool-path=/etc/pgbackrest/spool#' -e "s/process-max=3/process-max=$threads/" "$pgbackrest_config"
		;;
	off)
		sudo sed -i "s/archive_mode: 'on'/archive_mode: 'off'/" "$patroni_config"
		sudo systemctl restart postgresql
		;;
	*)
		echo 'Please specify whether you want to enable asynchronous archiving or to disable WAL archiving.'
		echo 'Usage: ./setup_pgbackrest.sh [async | off]'
		exit 1
		;;
esac
