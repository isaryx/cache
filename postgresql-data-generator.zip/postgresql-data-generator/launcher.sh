#!/bin/bash


node_storage=$1 # GiB
threads=$2
desired_utilisation=90 # Percentage of storage to use. Number must be less than 95.
octets_per_GiB=251593933 # xxd octets (2 characters each) per GiB of DB usage

cd "$(realpath "$(dirname "${BASH_SOURCE[0]}")")"

if ! (($node_storage)) || [[ "$node_storage" == '-'* ]]
then
	echo 'Please specify the size of the storage volume in GiB.'
	echo 'Usage: ./launcher.sh [storage size (GiB)] [threads | CALCULATE]'
	exit 1
elif [[ "$threads" == "CALCULATE" ]]
then
	threads=$((($(cat /proc/cpuinfo | grep $'processor' | tail -n 1 | sed 's/.*: //')+1)/2)) # Threads = cores/2, rounded down. Necessary to let pgbackrest keep up.
elif ! (($threads)) || [[ "$threads" == '-'* ]]
then
	echo 'Please specify the number of threads to use to load data, or specify that this should be calculated for you.'
	echo 'Usage: ./launcher.sh [storage size (GiB)] [threads | CALCULATE]'
	exit 1
fi

GiB_to_use=$(($node_storage*$desired_utilisation/100))
total_octets=$(($GiB_to_use*octets_per_GiB))
octets_per_thread=$(($total_octets/$threads))
chunk_size_octets=$(($octets_per_thread/20)) # Threads*chunk_size_octets == 5% of total_octets
loops=20


psql -c "DROP TABLE IF EXISTS hashTable" \
     -c "CREATE TABLE IF NOT EXISTS hashTable (hash text, process integer) PARTITION BY LIST (process)"

i=1
while [[ $i -le $threads ]]
do
	psql -c "CREATE TABLE IF NOT EXISTS hashTable$i PARTITION OF hashTable FOR VALUES IN ($i)"
	i=$(($i+1))
done

i=1
while [[ $i -le $threads ]]
do
	screen -d -m ./worker.sh $i $desired_utilisation $chunk_size_octets $loops
	i=$(($i+1))
done

screen -d -m ./lag_logger.sh
